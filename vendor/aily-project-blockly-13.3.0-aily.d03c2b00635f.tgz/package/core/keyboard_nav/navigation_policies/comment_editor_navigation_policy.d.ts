/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
import { CommentEditor } from '../../comments/comment_editor.js';
import type { IFocusableNode } from '../../interfaces/i_focusable_node.js';
import type { INavigationPolicy } from '../../interfaces/i_navigation_policy.js';
/**
 * Set of rules controlling keyboard navigation from a comment editor.
 * This is a no-op placeholder (other than isNavigable/isApplicable) since
 * comment editors handle their own navigation when editing ends.
 */
export declare class CommentEditorNavigationPolicy implements INavigationPolicy<CommentEditor> {
    getFirstChild(_current: CommentEditor): IFocusableNode | null;
    getParent(_current: CommentEditor): IFocusableNode | null;
    getNextSibling(_current: CommentEditor): IFocusableNode | null;
    getPreviousSibling(_current: CommentEditor): IFocusableNode | null;
    /**
     * Returns the row ID of the given comment editor.
     *
     * @param current The comment editor to retrieve the row ID of.
     * @returns The row ID of the given comment editor.
     */
    getRowId(current: CommentEditor): string;
    /**
     * Returns whether or not the given comment editor can be navigated to.
     *
     * @param current The instance to check for navigability.
     * @returns False.
     */
    isNavigable(current: CommentEditor): boolean;
    /**
     * Returns whether the given object can be navigated from by this policy.
     *
     * @param current The object to check if this policy applies to.
     * @returns True if the object is a CommentEditor.
     */
    isApplicable(current: any): current is CommentEditor;
}
//# sourceMappingURL=comment_editor_navigation_policy.d.ts.map